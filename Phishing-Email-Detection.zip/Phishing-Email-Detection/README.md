# Phishing Email Detection Model

## Overview
This project is a machine learning based phishing email detection system developed using Python and Scikit-learn.

The model classifies emails as:
- Phishing
- Safe

using textual content and suspicious URL analysis.

---

## Features
- Train on phishing and safe email dataset
- Extract email features using TF-IDF
- Detect suspicious phishing emails
- Display model accuracy
- Generate confusion matrix
- Test custom email input

---

## Technologies Used
- Python
- Scikit-learn
- Pandas
- Matplotlib
- Seaborn

---

## Installation

Install required libraries:

```bash
pip install -r requirements.txt